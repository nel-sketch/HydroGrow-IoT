# HydroGrow — GitHub Pages + Supabase + Arduino Uno / ESP-01

**Starter implementation, not deployed or hardware validated.** Static dashboard in `docs/`, hosted on GitHub Pages. Cloud API/database in `supabase/`. Separate Arduino Uno firmware and ESP-01 HTTPS bridge firmware. **A public GitHub Pages site does not host an API or camera feed.**

## Architecture

- Browser on GitHub Pages -> Supabase Auth + Postgres with RLS (HTTPS)
- Admin requests OFF/ON/AUTO -> `commands` table -> ESP-01 polls secured Edge Function -> Arduino Uno independently allows/blocks -> ack returned via telemetry.
- Uno sensors -> UART telemetry -> ESP-01 HTTPS POST -> Supabase Edge Function -> Postgres -> dashboard refresh (~12s).
- ESP32-CAM: separate authenticated HTTPS streaming gateway is **not included**. Plain LAN `http://camera-ip:81/stream` cannot be embedded directly in an HTTPS GitHub Pages site over the public internet.

## Before doing anything

1. Disconnect the physical pump load; work with a low-voltage test load.
2. You previously showed a Wi-Fi password and development device key in screenshots. Change those credentials. **Never commit actual Wi-Fi credentials, device tokens, admin passwords, service-role keys, or private certificates to GitHub.** This repo contains placeholders only. Avoid committing Arduino .ino or ESP sketch after adding actual credentials; store your secrets in ignored local headers for long-term maintenance.
3. No reliable unattended irrigation schedule is provided: AUTO only records mode and stops the pump. pH is voltage only, not calibrated pH.
4. GitHub Pages files are publicly accessible, even though login controls the data. Keep sensor/control data protected by Supabase RLS and Edge Function authentication.

## A. Create Supabase backend

1. Create a project at https://supabase.com/dashboard.
2. Disable open signups in Auth settings as appropriate, create/invite your administrator, verify their email, note their **Auth user UUID**.
3. Paste `supabase/schema.sql` into SQL Editor and execute.
4. Register a device from the SQL Editor (replace UUID with your actual authenticated admin user UUID):

```sql
insert into public.devices (id, owner_id, label)
values ('hydrogrow-uno-01', 'PASTE_REAL_ADMIN_USER_UUID', 'HydroGrow Uno');
```

5. Generate a fresh random 32+ character device secret. Set it only as an Edge Function secret and in your **local**, uncommitted ESP-01 configuration. Use the same ID as in `docs/config.js`.
6. Install Supabase CLI, then in the repo root run commands below (replace placeholders; do not put secret values in a git tracked script):

```sh
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set HYDRO_DEVICE_ID=hydrogrow-uno-01 HYDRO_DEVICE_TOKEN=YOUR_NEW_RANDOM_DEVICE_SECRET
supabase functions deploy device --no-verify-jwt
```

The platform JWT gate is disabled for the **device function only**, because the ESP device uses a dedicated secret sent in `x-device-key`; the function checks that secret *before* database access. Never publish `SUPABASE_SERVICE_ROLE_KEY`. Project hosted functions should supply it server-side. If the service-role environment variable is unavailable, deployment must be fixed server-side, never by exposing it in `docs/config.js`.

## B. Publish with GitHub Pages

1. Open `docs/config.js` and set Supabase project URL and **publishable** API key (both browser-safe values, not a service-role key) and device ID.
2. Create a GitHub repo (e.g. `HydroGrow-IoT`) and upload this project preserving its directories. **Inspect each file for actual secrets first.**
3. Repository -> **Settings -> Pages** -> Build and deployment: **Deploy from a branch** -> branch `main`, folder `/docs` -> Save. GitHub Pages supports `/docs` as a branch publishing source.
4. Open the displayed Pages URL, normally `https://YOUR_USERNAME.github.io/HydroGrow-IoT/`, and sign in using your Supabase Auth admin account. It will show offline until real telemetry arrives.
5. Check the GitHub Actions / Pages deployment log if the site returns 404. The default branch name may differ.

## C. Reflash ESP-01 (required for this variant)

Your existing LAN setup uses **ESP-01 AT firmware**. The cloud sketch in `esp01/HydroGrow_ESP01_Bridge` is **different firmware** that replaces AT firmware. A direct cloud connection needs real, validated HTTPS certificate verification. Do not use `setInsecure()` or unencrypted HTTP.

- Verify ESP-01 flash size and available memory for ESP8266 Arduino + BearSSL. Some ESP-01 hardware may be too constrained for this method.
- Flash using a 3.3V USB-to-UART programmer and stable 3.3V supply; do not connect 5V directly to ESP-01. GPIO0 goes LOW during programming then normal state for running.
- Configure SSID, password, Supabase Function URL, device secret in the bridge sketch **locally only**, never commit these changes.
- Replace `root_ca.h` placeholder with the real independently verified CA certificate PEM for your Supabase HTTPS domain, confirm accurate NTP time, and test TLS. CA chain can change; verify and maintain it.
- Connect bridge UART to Uno: ESP TX -> Uno D10; Uno D11 -> **logic level shifter** -> ESP RX; common GND. 9600 baud.
- Upload `arduino/HydroGrow_Uno_Cloud/HydroGrow_Uno_Cloud.ino` to Arduino Uno (install Adafruit DHT, RTClib, LiquidCrystal_I2C). **Do not use the old LAN Uno sketch with the HTTPS bridge.**
- Verify DHT D2, float D3/GND, relay D7, pH A0, LCD and RTC SDA A4/SCL A5. Test actual float polarity (`FLOAT_HIGH_LEVEL`) and relay active level. Pump defaults OFF and `ENABLE_PUMP_CONTROL=false`.

**Alternative preserving AT firmware:** keep your working local Node.js gateway and develop a trusted local-to-cloud sync service. It would run on an always-on PC or Raspberry Pi, terminate HTTPS, and enforce authentication. That gateway is **not implemented in this package**. Do not publish LAN port 8080 to the internet.

## D. Verify (pump load disconnected)

1. Confirm admin sign-in succeeds and `Controller OFFLINE` appears before telemetry.
2. Verify the ESP HTTPS bridge can reach Supabase with root certificate verification enabled.
3. Check Edge Function logs for errors and verify first record arrives in the `telemetry` table; refreshed dashboard should show `ONLINE` within ~45 sec.
4. Move float switch between HIGH and LOW and check dashboard; check temperature/humidity, and pH **voltage**.
5. Request `OFF`, verify command receipt and acknowledgement; `ON` will be **blocked by default** until pump enable is explicitly set and sensor tests pass.
6. Confirm pH calibration independently before using actual pH values in any decisions.

## Security and operational limitations

- Client data access is controlled by Row Level Security. Auth is required to insert commands. Device token is checked in the Edge Function before DB access.
- On-device low-water and 30-second run-time safeguards provide a backstop; they are not a substitute for electrical overcurrent protection, watchdogs, physically safe relays, and independent dry-run protection. Remote commands are not intrinsically failsafe.
- Camera gateway, secure remote video access, automatic schedules, SMS/email/push alerts, and production-grade device-token rotation are **not implemented**. Recorded alerts and on-screen offline indicator exist.
- Status is not guaranteed real-time: telemetry/poll are periodic. Network loss, weak ESP-01 RAM, and command expiry need physical validation.
- The dashboard's OFF request is remote: if Wi-Fi is down, the pump cannot receive it. It must fail safe locally.

## Files

- `docs/` - GitHub Pages website.
- `supabase/schema.sql` - RLS-protected tables.
- `supabase/functions/device/index.ts` - token-authenticated HTTPS device endpoint.
- `supabase/config.toml` - Edge Function JWT-gate config.
- `arduino/` - Uno sensor and pump control code.
- `esp01/` - custom ESP-01 BearSSL HTTPS bridge.

This package provides deployable source code and setup; it is **not yet live** until you configure your accounts and complete hardware testing.
