#pragma once
// REPLACE with the genuine PEM certificate of the CA that signs your
// YOUR_PROJECT.supabase.co HTTPS endpoint. Do not paste the website's
// private key. Verify the root CA using a trusted desktop tool or browser.
// Do not deploy until populated with the real CA certificate.
static const char ROOT_CA_PEM[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
REPLACE_WITH_VERIFIED_ROOT_CA_PEM
-----END CERTIFICATE-----
)EOF";
