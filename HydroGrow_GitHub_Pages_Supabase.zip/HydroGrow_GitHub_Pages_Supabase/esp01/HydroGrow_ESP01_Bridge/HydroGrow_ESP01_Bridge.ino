/* ESP-01 custom HTTPS bridge (ESP8266 Arduino core, NOT AT firmware).
   Requires trustworthy server ROOT CA PEM supplied in root_ca.h, valid NTP time.
   NO setInsecure(), no HTTP fallback. Flash ESP-01 with 3.3V USB-UART programmer.
   Serial GPIO3 RX <- Uno D11 through level shifter; GPIO1 TX -> Uno D10.
   ESP-01 should have an adequate 3.3V regulated supply. UART 9600.
*/
#include <ESP8266WiFi.h>
#include <WiFiClientSecureBearSSL.h>
#include <ESP8266HTTPClient.h>
#include <time.h>
#include "root_ca.h"
const char WIFI_SSID[]="YOUR_2_4GHZ_WIFI";
const char WIFI_PASS[]="YOUR_WIFI_PASSWORD";
const char FUNCTION_URL[]="https://YOUR_PROJECT.supabase.co/functions/v1/device";
const char DEVICE_TOKEN[]="REPLACE_WITH_LONG_RANDOM_DEVICE_TOKEN";
BearSSL::X509List trust(ROOT_CA_PEM);
char lineBuf[100];byte linePos=0;
unsigned long lastPoll=0,lastConnectTry=0;
bool timeReady(){return time(nullptr)>1700000000;}
void wifiConnect(){
  if(WiFi.status()==WL_CONNECTED)return;
  if(millis()-lastConnectTry<8000)return;lastConnectTry=millis();WiFi.mode(WIFI_STA);WiFi.begin(WIFI_SSID,WIFI_PASS);
}
bool tlsRequest(const String& endpoint, const String* payload, String& reply){
  if(WiFi.status()!=WL_CONNECTED||!timeReady())return false;
  BearSSL::WiFiClientSecure client;
  client.setTrustAnchors(&trust);
  client.setTimeout(8000);
  HTTPClient http;
  if(!http.begin(client,String(FUNCTION_URL)+endpoint))return false;
  http.setTimeout(8000);
  http.addHeader("x-device-key",DEVICE_TOKEN);
  int status;
  if(payload){http.addHeader("Content-Type","application/json");status=http.POST(*payload);}
  else status=http.GET();
  if(status==200)reply=http.getString();
  http.end();return status==200;
}
// DATA,t,h,v,water,pump,ackid,ackstatus
void sendData(const char* raw){
  String s(raw);String f[7];int start=5;
  for(byte i=0;i<7;i++){
    int end=s.indexOf(',',start);
    if(end<0){if(i!=6)return;end=s.length();}
    f[i]=s.substring(start,end);start=end+1;
  }
  // These are bounded strings coming from the trusted Uno, not arbitrary browser input.
  String json="{\"temperature\":"+f[0]+",\"humidity\":"+f[1]+
   ",\"ph_voltage\":"+f[2]+",\"water_high\":"+(f[3]=="1"?"true":"false")+
   ",\"pump_on\":"+(f[4]=="1"?"true":"false")+
   ",\"ack_id\":"+f[5]+",\"ack_status\":\""+f[6]+"\"}";
  String r;tlsRequest("/telemetry",&json,r);
}
void pollCommand(){String reply;if(!tlsRequest("/poll",nullptr,reply))return;
  reply.trim();int bar=reply.indexOf('|');if(bar<0)return;
  String id=reply.substring(0,bar),action=reply.substring(bar+1);
  if(action=="ON"||action=="OFF"||action=="AUTO"){
    Serial.print("CMD,");Serial.print(id);Serial.print(',');Serial.println(action);
  }
}
void setup(){
  Serial.begin(9600); // UART linked to Uno: don't print passwords or debug logs
  WiFi.persistent(false);wifiConnect();
  configTime(0,0,"pool.ntp.org","time.google.com"); // accurate time needed to validate TLS certificates
}
void loop(){
  wifiConnect();
  while(Serial.available()){
    char c=(char)Serial.read();
    if(c=='\n'||c=='\r'){
      if(linePos){lineBuf[linePos]=0;if(strncmp(lineBuf,"DATA,",5)==0)sendData(lineBuf);linePos=0;}
    }else if(linePos<sizeof(lineBuf)-1)lineBuf[linePos++]=c;else linePos=0;
  }
  if(millis()-lastPoll>12000UL){lastPoll=millis();pollCommand();}
  yield();
}
