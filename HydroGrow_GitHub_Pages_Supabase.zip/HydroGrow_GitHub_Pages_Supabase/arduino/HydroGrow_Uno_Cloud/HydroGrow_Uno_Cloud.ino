/* HydroGrow Uno Cloud - independent pump safety; ESP-01 runs custom HTTPS bridge firmware.
  Wiring: D2 DHT11, D3 float to GND, D7 relay, A0 pH PO, A4/A5 RTC+LCD,
  D10 RX<-ESP TX, D11 TX->level shifter->ESP RX. Verify relay and float polarity.
  Arduino IDE libraries: Adafruit DHT, RTClib, LiquidCrystal_I2C.
  CLOUD PUMP CONTROL IS DISABLED UNTIL ENABLE_PUMP_CONTROL IS SET TRUE AFTER DRY TEST.
*/
#include <Wire.h>
#include <SoftwareSerial.h>
#include <DHT.h>
#include <RTClib.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>
const byte PIN_DHT=2,PIN_FLOAT=3,PIN_RELAY=7,PIN_PH=A0;
const bool RELAY_ACTIVE_LOW=true;
const byte FLOAT_HIGH_LEVEL=LOW; // MUST TEST: change to HIGH if needed
const bool ENABLE_PUMP_CONTROL=false; // set true ONLY after dry relay and float tests
const unsigned long MAX_PUMP_MS=30000UL;
const unsigned long SENSOR_MS=2500UL,SEND_MS=12000UL;
DHT dht(PIN_DHT,DHT11);
SoftwareSerial esp(10,11); // 9600 baud, level shift D11->ESP RX
RTC_DS3231 rtc;
LiquidCrystal_I2C lcd(0x27,16,2);
float temperature=NAN,humidity=NAN,phV=0;
byte floatRaw=HIGH;
bool pumpOn=false,rtcOk=false,autoMode=false;
unsigned long pumpStart=0,lastRead=0,lastSend=0;
unsigned long ackId=0,seenCommand=0;
const char* ackStatus="none";
char rx[45];byte rxPos=0;
void pump(bool on){digitalWrite(PIN_RELAY,on?(RELAY_ACTIVE_LOW?LOW:HIGH):(RELAY_ACTIVE_LOW?HIGH:LOW));pumpOn=on;if(on)pumpStart=millis();}
bool waterHigh(){return floatRaw==FLOAT_HIGH_LEVEL;}
void readSensors(){
  temperature=dht.readTemperature();humidity=dht.readHumidity();floatRaw=digitalRead(PIN_FLOAT);
  long adc=0;for(byte i=0;i<8;i++)adc+=analogRead(PIN_PH);
  phV=(adc/8.0)*5.0/1023.0; // volts only; pH probe is NOT calibrated
  if(pumpOn && (!waterHigh()||millis()-pumpStart>=MAX_PUMP_MS)){
    pump(false);Serial.println(F("SAFETY SHUTOFF"));
  }
}
void display(){lcd.setCursor(0,0);lcd.print(F("T:"));if(isnan(temperature))lcd.print(F("ERR"));else lcd.print(temperature,1);
  lcd.print(F(" H:"));if(isnan(humidity))lcd.print(F("ERR"));else lcd.print(humidity,0);lcd.print(F("   "));
  lcd.setCursor(0,1);lcd.print(F("pV:"));lcd.print(phV,2);lcd.print(waterHigh()?F(" W:H"):F(" W:L"));lcd.print(pumpOn?F(" ON "):F(" OFF"));
}
void sendTelemetry(){
  esp.print(F("DATA,"));
  if(isnan(temperature))esp.print(F("null"));else esp.print(temperature,1);esp.print(',');
  if(isnan(humidity))esp.print(F("null"));else esp.print(humidity,0);esp.print(',');
  esp.print(phV,3);esp.print(',');esp.print(waterHigh()?1:0);esp.print(',');esp.print(pumpOn?1:0);
  esp.print(',');esp.print(ackId);esp.print(',');esp.println(ackStatus);
  Serial.print(F("T="));Serial.print(temperature);Serial.print(F(" H="));Serial.print(humidity);
  Serial.print(F(" pV="));Serial.print(phV,2);Serial.print(F(" water="));Serial.print(waterHigh()?F("HIGH"):F("LOW"));
  Serial.print(F(" pump="));Serial.println(pumpOn?F("ON"):F("OFF"));
}
void parseCommand(char *line){
  if(strncmp(line,"CMD,",4)!=0)return;
  char* p=line+4;char* separator=strchr(p,',');if(!separator)return;*separator='\0';
  unsigned long id=strtoul(p,nullptr,10);
  if(id==0 || id<=seenCommand)return;
  seenCommand=id;ackId=id;char* mode=separator+1;
  if(!strcmp(mode,"OFF")){pump(false);autoMode=false;ackStatus="executed";}
  else if(!strcmp(mode,"AUTO")){pump(false);autoMode=true;ackStatus="executed";} // no autonomous schedule until validated
  else if(!strcmp(mode,"ON")){
    autoMode=false;
    if(ENABLE_PUMP_CONTROL && waterHigh()){pump(true);ackStatus="executed";}
    else{pump(false);ackStatus="blocked";}
  }else{ackStatus="blocked";}
  Serial.print(F("Cloud CMD "));Serial.print(id);Serial.print(F(" "));Serial.print(mode);Serial.print(F(" -> "));Serial.println(ackStatus);
}
void setup(){
  digitalWrite(PIN_RELAY,RELAY_ACTIVE_LOW?HIGH:LOW);pinMode(PIN_RELAY,OUTPUT);pump(false);
  pinMode(PIN_FLOAT,INPUT_PULLUP);Serial.begin(9600);esp.begin(9600);dht.begin();Wire.begin();
  lcd.init();lcd.backlight();lcd.clear();lcd.print(F("HydroGrow Cloud"));
  rtcOk=rtc.begin(); // RTC available for future schedule, unused until validated
  delay(2000);readSensors();display();
  Serial.println(F("UNO CLOUD READY - PUMP DEFAULT OFF"));
}
void loop(){
  while(esp.available()){
    char c=esp.read();if(c=='\n'||c=='\r'){if(rxPos){rx[rxPos]=0;parseCommand(rx);rxPos=0;}}
    else if(rxPos<sizeof(rx)-1)rx[rxPos++]=c;else rxPos=0;
  }
  if(millis()-lastRead>=SENSOR_MS){lastRead=millis();readSensors();display();}
  if(millis()-lastSend>=SEND_MS){lastSend=millis();sendTelemetry();}
  if(pumpOn && (!waterHigh()||millis()-pumpStart>=MAX_PUMP_MS))pump(false);
}
